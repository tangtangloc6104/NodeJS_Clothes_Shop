<template>
  <div>
    <ProductList/>
  </div>
</template>

<script>
import ProductList from './AppProduct.vue';

export default {
  name: 'AppHome',
  components: {
    ProductList,
  },
};
</script>
<style>
</style>
